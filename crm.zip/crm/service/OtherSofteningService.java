package com.czip.crm.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.czip.crm.dao.OtherSofteningMapper;
import com.czip.crm.vo.OtherSoftening;
import org.springframework.stereotype.Service;
/**   
 * @author: Na
 * 
 */
@Service
public class OtherSofteningService extends ServiceImpl<OtherSofteningMapper, OtherSoftening> {
	
}