package com.czip.crm.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.czip.crm.vo.OtherSoftening;
import org.apache.ibatis.annotations.Mapper;

/**   
 * @author: Na
 * 
 */
@Mapper
public interface OtherSofteningMapper extends BaseMapper<OtherSoftening> {
	
}
