package com.czip.crm.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.czip.crm.vo.DesignYear;
import org.apache.ibatis.annotations.Mapper;

/**   
 * @author: Na
 * 
 */
@Mapper
public interface DesignYearMapper extends BaseMapper<DesignYear> {
	
}
