package com.czip.crm.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.czip.crm.vo.DataLog;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author: Na
 * 
 */
@Mapper
public interface DataLogMapper extends BaseMapper<DataLog> {
	
}
