package com.czip.crm.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.czip.crm.vo.OtherTrademark;
import org.apache.ibatis.annotations.Mapper;

/**   
 * @author: Na
 * 
 */
@Mapper
public interface OtherTrademarkMapper extends BaseMapper<OtherTrademark> {
	
}
